<?php

namespace Dwm\ApiBundle\Controller;

use Dwm\ApiBundle\Entity\Groupe;
use Dwm\ApiBundle\Entity\User;
use Dwm\ApiBundle\Form\GroupeType;
use Dwm\ApiBundle\Form\UserType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

class DefaultController extends Controller
{
    /**
     * @Route("/hello/{name}")
     * @Template()
     */
    public function indexAction($name)
    {
        return array('name' => $name);
    }


    /**
     * @Route("/users")
     * @Template()
     */

    public function usersAction()
    {
        $em=$this->getDoctrine()->getManager();
        $User=new User();
        $form=$this->createForm(new UserType(),$User);

        $request=$this->getRequest();
        //verifier l'envoi de données
        if($request->getMethod()=='POST'){
            $form->handleRequest($request);
            if($form->isValid()){
                $em->persist($User);
                $em->flush();

            }
        }
        $users=$this->getDoctrine()->getRepository("DwmApiBundle:User")->findAll();
        return $this->render('DwmApiBundle:default:users.html.twig',array("form"=>$form->createView(),'users'=>$users));
    }

    /**
     * @Route("/afficheUser")
     * @Template()
     */

    public function afficheUserAction()
    {
        $em=$this->getDoctrine()->getManager();
        $users=$em->getRepository("DwmApiBundle:User")->findAll();


        return $this->render('DwmApiBundle:default:afficheUser.html.twig',array('users'=>$users));
    }

/**
* @Route("/user/{id}")
* @Template()
*/
    public function userAction($id)
    {
        $em=$this->getDoctrine()->getManager();
        $User=$em->getRepository('DwmApiBundle:User')->find($id);
        $form=$this->createForm(new UserType(),$User);

        $request=$this->getRequest();
        //verifier l'envoi de données
        if($request->getMethod()=='POST'){
            $form->handleRequest($request);
            if($form->isValid()){
                $em->persist($User);
                $em->flush();

            }
        }

        return $this->render('DwmApiBundle:default:modifUser.html.twig',array("form"=>$form->createView(),));
    }


    /**
     * @Route("/groups")
     * @Template()
     */

    public function groupesAction()
    {
        $em=$this->getDoctrine()->getManager();
        $Groupe=new Groupe();
        $form=$this->createForm(new GroupeType(),$Groupe);

        $request=$this->getRequest();
        //verifier l'envoi de données
        if($request->getMethod()=='POST'){
            $form->handleRequest($request);
            if($form->isValid()){
                $em->persist($Groupe);
                $em->flush();

            }
        }
        $users=$this->getDoctrine()->getRepository("DwmApiBundle:Groupe")->findAll();
        return $this->render('DwmApiBundle:default:groupes.html.twig',array("form"=>$form->createView(),'users'=>$users));
    }


    /**
     * @Route("/afficheGroupe")
     * @Template()
     */

    public function afficheGroupeAction()
    {
        $em=$this->getDoctrine()->getManager();
        $groupes=$em->getRepository("DwmApiBundle:Groupe")->findAll();


        return $this->render('DwmApiBundle:default:afficheGroupe.html.twig',array('groupes'=>$groupes));
    }


/**
* @Route("/group/{id}")
* @Template()
*/
    public function groupAction($id)
    {
        $em=$this->getDoctrine()->getManager();
        $Groupe=$em->getRepository('DwmApiBundle:Groupe')->find($id);
        $form=$this->createForm(new GroupeType(),$Groupe);

        $request=$this->getRequest();
        //verifier l'envoi de données
        if($request->getMethod()=='POST'){
            $form->handleRequest($request);
            if($form->isValid()){
                $em->persist($Groupe);
                $em->flush();

            }
        }

        return $this->render('DwmApiBundle:default:modifGroupe.html.twig',array("form"=>$form->createView(),));
    }




}
