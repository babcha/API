<?php

namespace Dwm\ApiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DwmApiBundle extends Bundle
{
}
