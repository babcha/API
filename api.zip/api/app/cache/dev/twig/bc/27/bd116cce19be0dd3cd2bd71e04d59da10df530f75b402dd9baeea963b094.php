<?php

/* DwmApiBundle:default:afficheGroupe.html.twig */
class __TwigTemplate_bc27bd116cce19be0dd3cd2bd71e04d59da10df530f75b402dd9baeea963b094 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1> liste des Groupe</h1>

<table width=\"40%\">
    <tr align=\"left\">
        <th>ID</th>
        <th>Nom</th>


    </tr>

    ";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["groupes"]) ? $context["groupes"] : $this->getContext($context, "groupes")));
        foreach ($context['_seq'] as $context["_key"] => $context["groupe"]) {
            // line 12
            echo "        <tr>
            <td> ";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["groupe"]) ? $context["groupe"] : $this->getContext($context, "groupe")), "id"), "html", null, true);
            echo "</td>
            <td> ";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["groupe"]) ? $context["groupe"] : $this->getContext($context, "groupe")), "nom"), "html", null, true);
            echo "</td>

        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['groupe'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "</table>";
    }

    public function getTemplateName()
    {
        return "DwmApiBundle:default:afficheGroupe.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 18,  42 => 14,  38 => 13,  35 => 12,  31 => 11,  19 => 1,);
    }
}
