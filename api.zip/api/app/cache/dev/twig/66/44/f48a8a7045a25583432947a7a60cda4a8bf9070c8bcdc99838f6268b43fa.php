<?php

/* DwmApiBundle:default:modifGroupe.html.twig */
class __TwigTemplate_6644f48a8a7045a25583432947a7a60cda4a8bf9070c8bcdc99838f6268b43fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1 align=\"center\"> modif Groupe</h1>
<form method=\"post\">
    <table>


        <tr>
            <td>";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nom"), 'label');
        echo "</td>
            <td>";
        // line 8
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nom"), 'widget');
        echo "</td>
            <td>";
        // line 9
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nom"), 'errors');
        echo "</td>
        </tr>

    </table>
    ";
        // line 13
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'rest');
        echo "<!-- il faut les ajouter tjr a la fin-->
    <input type=\"submit\" value=\"Modifier\">
</form>";
    }

    public function getTemplateName()
    {
        return "DwmApiBundle:default:modifGroupe.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  42 => 13,  35 => 9,  31 => 8,  27 => 7,  19 => 1,);
    }
}
